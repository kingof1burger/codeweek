9F ABHIROOP KAPOOR ENTRY

In my entry, I have decided to use Xiaomi as my choice of e-commerce website.

The main page showcases a carousel with devices, directing you to the products page. Below that
there is a gallery of links showcasing some offers and collections ongoing in the website. Below that you will find 
a short point by point of the website's function and how to use it, after which you can find two testimonials.

The navbar moves with your window, and the footer has a 3 line description of Tradeforce, with some hyperlinks.
(try the hyperlinks for a surprise)

than comes our about page, self explanatory.

after which comes the products page, showcasing 16 accessories. Hover over the images for adding them
to cart and buying them (Note: this function is just for redirecting to the products page, as i do not know javascript i 
)

Than comes the Contact page, this is where one can ask for offers, and request orders, and other such FAQs.

Than comes the cart, this is just a showcase page, because i couldn't figure out how to use css and html for 
adding and removing items from cart, or increasing and decreasing amount etc.

Hope you enjoy the website's look! (If you give us the win there is a free cookie in it for you)

From,
Team 9F Abhiroop Kapoor

